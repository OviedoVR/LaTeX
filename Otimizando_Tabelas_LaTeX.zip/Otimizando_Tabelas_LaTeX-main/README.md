# Otimizando a criação de tabelas em LaTeX

Neste projeto, mostro como otimizar a criação de **tabelas em LaTeX**, utilizando a ferramenta ***LaTeX Tables Generator*** e uma **metologia** própria que utilizo durante minha prestação de serviços como *freelancer* envolvendo **LaTeX typesetting** para clientes ao redor do mundo.

Vídeo: https://youtu.be/9p9RsjmAv0g

Metodologia:

<img width="650" alt="CRISP-DM Methodology" src="https://github.com/OviedoVR/Otimizando_Tabelas_LaTeX/blob/main/Tabelas_em_LaTeX.png">
