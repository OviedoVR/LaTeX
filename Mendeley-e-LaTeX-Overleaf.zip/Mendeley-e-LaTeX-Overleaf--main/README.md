# Mendeley-e-LaTeX-Overleaf-
Exportação de referências do Mendeley para o Overleaf


Neste projeto, referências do Mendeley são exportadas para o Overleaf, sem a necessidade de adquirir uma conta Premium para fazer essa integração.
Vídeo do youtube (tutorial): https://www.youtube.com/watch?v=0w0b_BO12UI
